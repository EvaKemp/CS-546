export const questionOne = (arr) => {
  // Implement question 1 here
  return; //return result
};

export const questionTwo = (obj1, obj2) => {
  // Implement question 2 here
  return; //return result
};

export const questionThree = (arr) => {
  // Implement question 3 here
  return; //return result
};

export const questionFour = (str) => {
  // Implement question 4 here
  return; //return result
};

//DO NOT FORGET TO UPDATE THE INFORMATION BELOW OR IT WILL BE -2 POINTS PER FIELD THAT IS MISSING.
export const studentInfo = {
  firstName: 'YOUR FIRST NAME',
  lastName: 'YOUR LAST NAME',
  studentId: 'YOUR STUDENT ID'
};
